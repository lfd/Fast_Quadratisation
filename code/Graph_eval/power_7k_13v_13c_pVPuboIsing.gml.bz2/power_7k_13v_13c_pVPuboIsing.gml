graph [
  node [
    id 0
    label "1"
    colour "lfdblack"
  ]
  node [
    id 1
    label "2"
    colour "lfdblack"
  ]
  node [
    id 2
    label "3"
    colour "lfdblack"
  ]
  node [
    id 3
    label "4"
    colour "lfdblack"
  ]
  node [
    id 4
    label "5"
    colour "lfdblack"
  ]
  node [
    id 5
    label "6"
    colour "lfdblack"
  ]
  node [
    id 6
    label "7"
    colour "lfdblack"
  ]
  node [
    id 7
    label "8"
    colour "lfdblack"
  ]
  node [
    id 8
    label "9"
    colour "lfdblack"
  ]
  node [
    id 9
    label "10"
    colour "lfdblack"
  ]
  node [
    id 10
    label "11"
    colour "lfdblack"
  ]
  node [
    id 11
    label "12"
    colour "lfdblack"
  ]
  node [
    id 12
    label "13"
    colour "lfdblack"
  ]
  node [
    id 13
    label "14"
    colour "lfdblack"
  ]
  node [
    id 14
    label "15"
    colour "lfdblack"
  ]
  node [
    id 15
    label "16"
    colour "lfdblack"
  ]
  edge [
    source 0
    target 5
    weight 173
    colour "lfdblack"
  ]
  edge [
    source 0
    target 7
    weight 159
    colour "lfdblack"
  ]
  edge [
    source 0
    target 11
    weight 161
    colour "lfdblack"
  ]
  edge [
    source 0
    target 12
    weight 132
    colour "lfdblack"
  ]
  edge [
    source 0
    target 15
    weight 105
    colour "lfdblack"
  ]
  edge [
    source 0
    target 4
    weight 83
    colour "lfdblack"
  ]
  edge [
    source 0
    target 6
    weight 175
    colour "lfdblack"
  ]
  edge [
    source 0
    target 10
    weight 81
    colour "lfdblack"
  ]
  edge [
    source 0
    target 3
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 0
    target 13
    weight 79
    colour "lfdblack"
  ]
  edge [
    source 0
    target 14
    weight 126
    colour "lfdblack"
  ]
  edge [
    source 0
    target 2
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 0
    target 1
    weight 114
    colour "lfdblack"
  ]
  edge [
    source 0
    target 9
    weight 76
    colour "lfdblack"
  ]
  edge [
    source 0
    target 8
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 1
    target 2
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 1
    target 3
    weight 56
    colour "lfdblack"
  ]
  edge [
    source 1
    target 5
    weight 122
    colour "lfdblack"
  ]
  edge [
    source 1
    target 10
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 1
    target 14
    weight 83
    colour "lfdblack"
  ]
  edge [
    source 1
    target 15
    weight 77
    colour "lfdblack"
  ]
  edge [
    source 1
    target 4
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 1
    target 7
    weight 70
    colour "lfdblack"
  ]
  edge [
    source 1
    target 9
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 1
    target 11
    weight 98
    colour "lfdblack"
  ]
  edge [
    source 1
    target 6
    weight 98
    colour "lfdblack"
  ]
  edge [
    source 1
    target 8
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 1
    target 13
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 2
    target 3
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 2
    target 5
    weight 62
    colour "lfdblack"
  ]
  edge [
    source 2
    target 10
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 2
    target 14
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 2
    target 15
    weight 62
    colour "lfdblack"
  ]
  edge [
    source 2
    target 6
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 2
    target 7
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 2
    target 12
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 2
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 5
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 10
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 3
    target 14
    weight 84
    colour "lfdblack"
  ]
  edge [
    source 3
    target 15
    weight 56
    colour "lfdblack"
  ]
  edge [
    source 3
    target 7
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 12
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 13
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 6
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 11
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 4
    target 5
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 6
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 7
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 10
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 4
    target 12
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 4
    target 9
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 4
    target 11
    weight 61
    colour "lfdblack"
  ]
  edge [
    source 4
    target 14
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 4
    target 15
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 5
    target 7
    weight 140
    colour "lfdblack"
  ]
  edge [
    source 5
    target 11
    weight 122
    colour "lfdblack"
  ]
  edge [
    source 5
    target 12
    weight 86
    colour "lfdblack"
  ]
  edge [
    source 5
    target 15
    weight 94
    colour "lfdblack"
  ]
  edge [
    source 5
    target 10
    weight 87
    colour "lfdblack"
  ]
  edge [
    source 5
    target 14
    weight 85
    colour "lfdblack"
  ]
  edge [
    source 5
    target 6
    weight 142
    colour "lfdblack"
  ]
  edge [
    source 5
    target 9
    weight 76
    colour "lfdblack"
  ]
  edge [
    source 5
    target 8
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 5
    target 13
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 6
    target 7
    weight 103
    colour "lfdblack"
  ]
  edge [
    source 6
    target 10
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 6
    target 12
    weight 78
    colour "lfdblack"
  ]
  edge [
    source 6
    target 15
    weight 102
    colour "lfdblack"
  ]
  edge [
    source 6
    target 8
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 6
    target 11
    weight 120
    colour "lfdblack"
  ]
  edge [
    source 6
    target 9
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 6
    target 14
    weight 106
    colour "lfdblack"
  ]
  edge [
    source 6
    target 13
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 7
    target 11
    weight 78
    colour "lfdblack"
  ]
  edge [
    source 7
    target 12
    weight 113
    colour "lfdblack"
  ]
  edge [
    source 7
    target 15
    weight 40
    colour "lfdblack"
  ]
  edge [
    source 7
    target 10
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 7
    target 13
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 7
    target 14
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 7
    target 9
    weight 76
    colour "lfdblack"
  ]
  edge [
    source 7
    target 8
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 8
    target 11
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 8
    target 9
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 8
    target 12
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 8
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 11
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 9
    target 14
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 9
    target 12
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 9
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 14
    weight 86
    colour "lfdblack"
  ]
  edge [
    source 10
    target 15
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 10
    target 12
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 10
    target 13
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 10
    target 11
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 11
    target 12
    weight 68
    colour "lfdblack"
  ]
  edge [
    source 11
    target 15
    weight 86
    colour "lfdblack"
  ]
  edge [
    source 11
    target 13
    weight 48
    colour "lfdblack"
  ]
  edge [
    source 11
    target 14
    weight 82
    colour "lfdblack"
  ]
  edge [
    source 12
    target 15
    weight 64
    colour "lfdblack"
  ]
  edge [
    source 12
    target 13
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 12
    target 14
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 13
    target 14
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 13
    target 15
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 14
    target 15
    weight 78
    colour "lfdblack"
  ]
]
