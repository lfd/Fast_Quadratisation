graph [
  node [
    id 0
    label "1"
    colour "lfdblack"
  ]
  node [
    id 1
    label "2"
    colour "lfdblack"
  ]
  node [
    id 2
    label "3"
    colour "lfdblack"
  ]
  node [
    id 3
    label "4"
    colour "lfdblack"
  ]
  node [
    id 4
    label "5"
    colour "lfdblack"
  ]
  node [
    id 5
    label "6"
    colour "lfdblack"
  ]
  node [
    id 6
    label "7"
    colour "lfdblack"
  ]
  node [
    id 7
    label "8"
    colour "lfdblack"
  ]
  node [
    id 8
    label "9"
    colour "lfdblack"
  ]
  node [
    id 9
    label "10"
    colour "lfdblack"
  ]
  node [
    id 10
    label "11"
    colour "lfdblack"
  ]
  node [
    id 11
    label "12"
    colour "lfdblack"
  ]
  node [
    id 12
    label "13"
    colour "lfdblack"
  ]
  node [
    id 13
    label "14"
    colour "lfdred"
  ]
  node [
    id 14
    label "15"
    colour "lfdred"
  ]
  edge [
    source 0
    target 5
    weight 7
    colour "lfdblack"
  ]
  edge [
    source 0
    target 7
    weight 13
    colour "lfdblack"
  ]
  edge [
    source 0
    target 9
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 0
    target 12
    weight 5
    colour "lfdblack"
  ]
  edge [
    source 0
    target 2
    weight 7
    colour "lfdblack"
  ]
  edge [
    source 0
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 11
    weight 9
    colour "lfdblack"
  ]
  edge [
    source 0
    target 14
    weight 12
    colour "lfdred"
  ]
  edge [
    source 0
    target 3
    weight 6
    colour "lfdblack"
  ]
  edge [
    source 0
    target 13
    weight 10
    colour "lfdred"
  ]
  edge [
    source 0
    target 6
    weight 10
    colour "lfdblack"
  ]
  edge [
    source 0
    target 10
    weight 6
    colour "lfdblack"
  ]
  edge [
    source 0
    target 1
    weight 5
    colour "lfdblack"
  ]
  edge [
    source 0
    target 4
    weight 7
    colour "lfdblack"
  ]
  edge [
    source 1
    target 5
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 1
    target 7
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 1
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 9
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 1
    target 13
    weight 4
    colour "lfdred"
  ]
  edge [
    source 1
    target 6
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 1
    target 11
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 1
    target 14
    weight 2
    colour "lfdred"
  ]
  edge [
    source 1
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 8
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 2
    target 11
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 2
    target 14
    weight 5
    colour "lfdred"
  ]
  edge [
    source 2
    target 3
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 2
    target 9
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 2
    target 13
    weight 3
    colour "lfdred"
  ]
  edge [
    source 2
    target 5
    weight 5
    colour "lfdblack"
  ]
  edge [
    source 2
    target 7
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 2
    target 4
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 2
    target 6
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 2
    target 10
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 3
    target 9
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 3
    target 13
    weight 3
    colour "lfdred"
  ]
  edge [
    source 3
    target 4
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 3
    target 5
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 3
    target 7
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 3
    target 10
    weight 5
    colour "lfdblack"
  ]
  edge [
    source 3
    target 6
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 3
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 14
    weight 5
    colour "lfdred"
  ]
  edge [
    source 3
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 5
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 4
    target 7
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 4
    target 10
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 4
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 14
    weight 6
    colour "lfdred"
  ]
  edge [
    source 4
    target 6
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 4
    target 11
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 4
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 9
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 5
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 10
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 5
    target 8
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 5
    target 13
    weight 2
    colour "lfdred"
  ]
  edge [
    source 5
    target 6
    weight 5
    colour "lfdblack"
  ]
  edge [
    source 5
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 14
    weight 2
    colour "lfdred"
  ]
  edge [
    source 6
    target 7
    weight 5
    colour "lfdblack"
  ]
  edge [
    source 6
    target 12
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 6
    target 14
    weight 6
    colour "lfdred"
  ]
  edge [
    source 6
    target 9
    weight 6
    colour "lfdblack"
  ]
  edge [
    source 6
    target 13
    weight 5
    colour "lfdred"
  ]
  edge [
    source 6
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 11
    weight 5
    colour "lfdblack"
  ]
  edge [
    source 6
    target 8
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 7
    target 9
    weight 7
    colour "lfdblack"
  ]
  edge [
    source 7
    target 12
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 7
    target 10
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 7
    target 14
    weight 6
    colour "lfdred"
  ]
  edge [
    source 7
    target 8
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 7
    target 11
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 7
    target 13
    weight 5
    colour "lfdred"
  ]
  edge [
    source 8
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 13
    weight 2
    colour "lfdred"
  ]
  edge [
    source 9
    target 12
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 9
    target 13
    weight 7
    colour "lfdred"
  ]
  edge [
    source 9
    target 10
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 9
    target 14
    weight 2
    colour "lfdred"
  ]
  edge [
    source 9
    target 11
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 10
    target 12
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 10
    target 11
    weight 3
    colour "lfdblack"
  ]
  edge [
    source 10
    target 14
    weight 4
    colour "lfdred"
  ]
  edge [
    source 10
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 14
    weight 7
    colour "lfdred"
  ]
  edge [
    source 11
    target 13
    weight 4
    colour "lfdred"
  ]
  edge [
    source 12
    target 14
    weight 2
    colour "lfdred"
  ]
  edge [
    source 12
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 14
    weight 6
    colour "lfdred"
  ]
]
