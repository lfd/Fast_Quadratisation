graph [
  node [
    id 0
    label "1"
    colour "lfdblack"
  ]
  node [
    id 1
    label "2"
    colour "lfdblack"
  ]
  node [
    id 2
    label "3"
    colour "lfdblack"
  ]
  node [
    id 3
    label "4"
    colour "lfdblack"
  ]
  node [
    id 4
    label "5"
    colour "lfdblack"
  ]
  node [
    id 5
    label "6"
    colour "lfdblack"
  ]
  node [
    id 6
    label "7"
    colour "lfdblack"
  ]
  node [
    id 7
    label "8"
    colour "lfdblack"
  ]
  node [
    id 8
    label "9"
    colour "lfdblack"
  ]
  node [
    id 9
    label "10"
    colour "lfdblack"
  ]
  node [
    id 10
    label "11"
    colour "lfdblack"
  ]
  node [
    id 11
    label "12"
    colour "lfdblack"
  ]
  node [
    id 12
    label "13"
    colour "lfdblack"
  ]
  edge [
    source 0
    target 5
    weight 44
    colour "lfdblack"
  ]
  edge [
    source 0
    target 7
    weight 35
    colour "lfdblack"
  ]
  edge [
    source 0
    target 9
    weight 41
    colour "lfdblack"
  ]
  edge [
    source 0
    target 11
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 0
    target 12
    weight 30
    colour "lfdblack"
  ]
  edge [
    source 0
    target 4
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 0
    target 6
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 0
    target 10
    weight 22
    colour "lfdblack"
  ]
  edge [
    source 0
    target 2
    weight 20
    colour "lfdblack"
  ]
  edge [
    source 0
    target 3
    weight 24
    colour "lfdblack"
  ]
  edge [
    source 0
    target 8
    weight 46
    colour "lfdblack"
  ]
  edge [
    source 0
    target 1
    weight 48
    colour "lfdblack"
  ]
  edge [
    source 1
    target 2
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 1
    target 3
    weight 36
    colour "lfdblack"
  ]
  edge [
    source 1
    target 5
    weight 28
    colour "lfdblack"
  ]
  edge [
    source 1
    target 8
    weight 39
    colour "lfdblack"
  ]
  edge [
    source 1
    target 9
    weight 48
    colour "lfdblack"
  ]
  edge [
    source 1
    target 10
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 1
    target 4
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 1
    target 7
    weight 8
    colour "lfdblack"
  ]
  edge [
    source 1
    target 11
    weight 48
    colour "lfdblack"
  ]
  edge [
    source 1
    target 6
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 2
    target 3
    weight 8
    colour "lfdblack"
  ]
  edge [
    source 2
    target 5
    weight 28
    colour "lfdblack"
  ]
  edge [
    source 2
    target 8
    weight 10
    colour "lfdblack"
  ]
  edge [
    source 2
    target 9
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 2
    target 10
    weight 16
    colour "lfdblack"
  ]
  edge [
    source 2
    target 7
    weight 8
    colour "lfdblack"
  ]
  edge [
    source 2
    target 12
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 2
    target 6
    weight 24
    colour "lfdblack"
  ]
  edge [
    source 2
    target 11
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 3
    target 5
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 3
    target 8
    weight 22
    colour "lfdblack"
  ]
  edge [
    source 3
    target 9
    weight 18
    colour "lfdblack"
  ]
  edge [
    source 3
    target 10
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 3
    target 7
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 3
    target 12
    weight 8
    colour "lfdblack"
  ]
  edge [
    source 3
    target 6
    weight 16
    colour "lfdblack"
  ]
  edge [
    source 3
    target 11
    weight 16
    colour "lfdblack"
  ]
  edge [
    source 4
    target 5
    weight 6
    colour "lfdblack"
  ]
  edge [
    source 4
    target 6
    weight 10
    colour "lfdblack"
  ]
  edge [
    source 4
    target 7
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 4
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 12
    weight 6
    colour "lfdblack"
  ]
  edge [
    source 4
    target 9
    weight 8
    colour "lfdblack"
  ]
  edge [
    source 4
    target 11
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 4
    target 8
    weight 4
    colour "lfdblack"
  ]
  edge [
    source 5
    target 7
    weight 30
    colour "lfdblack"
  ]
  edge [
    source 5
    target 9
    weight 36
    colour "lfdblack"
  ]
  edge [
    source 5
    target 11
    weight 42
    colour "lfdblack"
  ]
  edge [
    source 5
    target 12
    weight 14
    colour "lfdblack"
  ]
  edge [
    source 5
    target 8
    weight 20
    colour "lfdblack"
  ]
  edge [
    source 5
    target 10
    weight 14
    colour "lfdblack"
  ]
  edge [
    source 5
    target 6
    weight 54
    colour "lfdblack"
  ]
  edge [
    source 6
    target 7
    weight 16
    colour "lfdblack"
  ]
  edge [
    source 6
    target 10
    weight 10
    colour "lfdblack"
  ]
  edge [
    source 6
    target 12
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 6
    target 9
    weight 42
    colour "lfdblack"
  ]
  edge [
    source 6
    target 8
    weight 34
    colour "lfdblack"
  ]
  edge [
    source 6
    target 11
    weight 52
    colour "lfdblack"
  ]
  edge [
    source 7
    target 9
    weight 16
    colour "lfdblack"
  ]
  edge [
    source 7
    target 11
    weight 20
    colour "lfdblack"
  ]
  edge [
    source 7
    target 12
    weight 22
    colour "lfdblack"
  ]
  edge [
    source 7
    target 10
    weight 10
    colour "lfdblack"
  ]
  edge [
    source 7
    target 8
    weight 18
    colour "lfdblack"
  ]
  edge [
    source 8
    target 9
    weight 25
    colour "lfdblack"
  ]
  edge [
    source 8
    target 10
    weight 14
    colour "lfdblack"
  ]
  edge [
    source 8
    target 12
    weight 12
    colour "lfdblack"
  ]
  edge [
    source 8
    target 11
    weight 38
    colour "lfdblack"
  ]
  edge [
    source 9
    target 11
    weight 38
    colour "lfdblack"
  ]
  edge [
    source 9
    target 12
    weight 8
    colour "lfdblack"
  ]
  edge [
    source 9
    target 10
    weight 2
    colour "lfdblack"
  ]
  edge [
    source 10
    target 12
    weight 18
    colour "lfdblack"
  ]
  edge [
    source 10
    target 11
    weight 8
    colour "lfdblack"
  ]
  edge [
    source 11
    target 12
    weight 9
    colour "lfdblack"
  ]
]
