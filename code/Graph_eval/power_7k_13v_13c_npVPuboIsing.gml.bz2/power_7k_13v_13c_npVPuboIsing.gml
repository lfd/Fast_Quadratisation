graph [
  node [
    id 0
    label "1"
    colour "lfdblack"
  ]
  node [
    id 1
    label "2"
    colour "lfdblack"
  ]
  node [
    id 2
    label "3"
    colour "lfdblack"
  ]
  node [
    id 3
    label "4"
    colour "lfdblack"
  ]
  node [
    id 4
    label "5"
    colour "lfdblack"
  ]
  node [
    id 5
    label "6"
    colour "lfdblack"
  ]
  node [
    id 6
    label "7"
    colour "lfdblack"
  ]
  node [
    id 7
    label "8"
    colour "lfdblack"
  ]
  node [
    id 8
    label "9"
    colour "lfdblack"
  ]
  node [
    id 9
    label "10"
    colour "lfdblack"
  ]
  node [
    id 10
    label "11"
    colour "lfdblack"
  ]
  node [
    id 11
    label "12"
    colour "lfdblack"
  ]
  node [
    id 12
    label "13"
    colour "lfdblack"
  ]
  edge [
    source 0
    target 5
    weight 140
    colour "lfdblack"
  ]
  edge [
    source 0
    target 7
    weight 132
    colour "lfdblack"
  ]
  edge [
    source 0
    target 9
    weight 133
    colour "lfdblack"
  ]
  edge [
    source 0
    target 11
    weight 141
    colour "lfdblack"
  ]
  edge [
    source 0
    target 12
    weight 115
    colour "lfdblack"
  ]
  edge [
    source 0
    target 4
    weight 81
    colour "lfdblack"
  ]
  edge [
    source 0
    target 6
    weight 149
    colour "lfdblack"
  ]
  edge [
    source 0
    target 10
    weight 81
    colour "lfdblack"
  ]
  edge [
    source 0
    target 2
    weight 93
    colour "lfdblack"
  ]
  edge [
    source 0
    target 3
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 0
    target 8
    weight 138
    colour "lfdblack"
  ]
  edge [
    source 0
    target 1
    weight 94
    colour "lfdblack"
  ]
  edge [
    source 1
    target 2
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 1
    target 3
    weight 56
    colour "lfdblack"
  ]
  edge [
    source 1
    target 5
    weight 100
    colour "lfdblack"
  ]
  edge [
    source 1
    target 8
    weight 82
    colour "lfdblack"
  ]
  edge [
    source 1
    target 9
    weight 110
    colour "lfdblack"
  ]
  edge [
    source 1
    target 10
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 1
    target 4
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 1
    target 7
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 1
    target 11
    weight 88
    colour "lfdblack"
  ]
  edge [
    source 1
    target 6
    weight 76
    colour "lfdblack"
  ]
  edge [
    source 2
    target 3
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 2
    target 5
    weight 96
    colour "lfdblack"
  ]
  edge [
    source 2
    target 8
    weight 84
    colour "lfdblack"
  ]
  edge [
    source 2
    target 9
    weight 78
    colour "lfdblack"
  ]
  edge [
    source 2
    target 10
    weight 86
    colour "lfdblack"
  ]
  edge [
    source 2
    target 7
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 2
    target 12
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 2
    target 6
    weight 72
    colour "lfdblack"
  ]
  edge [
    source 2
    target 11
    weight 48
    colour "lfdblack"
  ]
  edge [
    source 3
    target 5
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 8
    weight 82
    colour "lfdblack"
  ]
  edge [
    source 3
    target 9
    weight 56
    colour "lfdblack"
  ]
  edge [
    source 3
    target 10
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 3
    target 7
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 12
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 6
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 3
    target 11
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 4
    target 5
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 6
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 7
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 10
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 4
    target 12
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 4
    target 9
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 11
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 4
    target 8
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 5
    target 7
    weight 115
    colour "lfdblack"
  ]
  edge [
    source 5
    target 9
    weight 124
    colour "lfdblack"
  ]
  edge [
    source 5
    target 11
    weight 107
    colour "lfdblack"
  ]
  edge [
    source 5
    target 12
    weight 76
    colour "lfdblack"
  ]
  edge [
    source 5
    target 8
    weight 104
    colour "lfdblack"
  ]
  edge [
    source 5
    target 10
    weight 85
    colour "lfdblack"
  ]
  edge [
    source 5
    target 6
    weight 112
    colour "lfdblack"
  ]
  edge [
    source 6
    target 7
    weight 85
    colour "lfdblack"
  ]
  edge [
    source 6
    target 10
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 6
    target 12
    weight 78
    colour "lfdblack"
  ]
  edge [
    source 6
    target 9
    weight 108
    colour "lfdblack"
  ]
  edge [
    source 6
    target 8
    weight 105
    colour "lfdblack"
  ]
  edge [
    source 6
    target 11
    weight 111
    colour "lfdblack"
  ]
  edge [
    source 7
    target 9
    weight 86
    colour "lfdblack"
  ]
  edge [
    source 7
    target 11
    weight 72
    colour "lfdblack"
  ]
  edge [
    source 7
    target 12
    weight 96
    colour "lfdblack"
  ]
  edge [
    source 7
    target 10
    weight 60
    colour "lfdblack"
  ]
  edge [
    source 7
    target 8
    weight 82
    colour "lfdblack"
  ]
  edge [
    source 8
    target 9
    weight 111
    colour "lfdblack"
  ]
  edge [
    source 8
    target 10
    weight 84
    colour "lfdblack"
  ]
  edge [
    source 8
    target 12
    weight 80
    colour "lfdblack"
  ]
  edge [
    source 8
    target 11
    weight 113
    colour "lfdblack"
  ]
  edge [
    source 9
    target 11
    weight 113
    colour "lfdblack"
  ]
  edge [
    source 9
    target 12
    weight 71
    colour "lfdblack"
  ]
  edge [
    source 9
    target 10
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 10
    target 12
    weight 58
    colour "lfdblack"
  ]
  edge [
    source 10
    target 11
    weight 32
    colour "lfdblack"
  ]
  edge [
    source 11
    target 12
    weight 53
    colour "lfdblack"
  ]
]
