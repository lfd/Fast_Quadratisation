graph [
  node [
    id 0
    label "1"
    colour "lfdblack"
  ]
  node [
    id 1
    label "2"
    colour "lfdblack"
  ]
  node [
    id 2
    label "3"
    colour "lfdblack"
  ]
  node [
    id 3
    label "4"
    colour "lfdblack"
  ]
  node [
    id 4
    label "5"
    colour "lfdblack"
  ]
  node [
    id 5
    label "6"
    colour "lfdblack"
  ]
  node [
    id 6
    label "7"
    colour "lfdblack"
  ]
  node [
    id 7
    label "8"
    colour "lfdblack"
  ]
  node [
    id 8
    label "9"
    colour "lfdblack"
  ]
  node [
    id 9
    label "10"
    colour "lfdblack"
  ]
  node [
    id 10
    label "11"
    colour "lfdblack"
  ]
  node [
    id 11
    label "12"
    colour "lfdblack"
  ]
  node [
    id 12
    label "13"
    colour "lfdblack"
  ]
  node [
    id 13
    label "14"
    colour "lfdblack"
  ]
  node [
    id 14
    label "15"
    colour "lfdblack"
  ]
  node [
    id 15
    label "16"
    colour "lfdred"
  ]
  node [
    id 16
    label "17"
    colour "lfdred"
  ]
  node [
    id 17
    label "18"
    colour "lfdred"
  ]
  node [
    id 18
    label "19"
    colour "lfdred"
  ]
  node [
    id 19
    label "20"
    colour "lfdred"
  ]
  node [
    id 20
    label "21"
    colour "lfdred"
  ]
  node [
    id 21
    label "22"
    colour "lfdred"
  ]
  node [
    id 22
    label "23"
    colour "lfdred"
  ]
  node [
    id 23
    label "24"
    colour "lfdred"
  ]
  node [
    id 24
    label "25"
    colour "lfdred"
  ]
  node [
    id 25
    label "26"
    colour "lfdred"
  ]
  node [
    id 26
    label "27"
    colour "lfdred"
  ]
  node [
    id 27
    label "28"
    colour "lfdred"
  ]
  node [
    id 28
    label "29"
    colour "lfdred"
  ]
  node [
    id 29
    label "30"
    colour "lfdred"
  ]
  node [
    id 30
    label "31"
    colour "lfdred"
  ]
  node [
    id 31
    label "32"
    colour "lfdred"
  ]
  node [
    id 32
    label "33"
    colour "lfdred"
  ]
  node [
    id 33
    label "34"
    colour "lfdred"
  ]
  node [
    id 34
    label "35"
    colour "lfdred"
  ]
  node [
    id 35
    label "36"
    colour "lfdred"
  ]
  node [
    id 36
    label "37"
    colour "lfdred"
  ]
  node [
    id 37
    label "38"
    colour "lfdred"
  ]
  node [
    id 38
    label "39"
    colour "lfdred"
  ]
  node [
    id 39
    label "40"
    colour "lfdred"
  ]
  node [
    id 40
    label "41"
    colour "lfdred"
  ]
  node [
    id 41
    label "42"
    colour "lfdred"
  ]
  node [
    id 42
    label "43"
    colour "lfdred"
  ]
  node [
    id 43
    label "44"
    colour "lfdred"
  ]
  node [
    id 44
    label "45"
    colour "lfdred"
  ]
  node [
    id 45
    label "46"
    colour "lfdred"
  ]
  node [
    id 46
    label "47"
    colour "lfdred"
  ]
  node [
    id 47
    label "48"
    colour "lfdred"
  ]
  node [
    id 48
    label "49"
    colour "lfdred"
  ]
  node [
    id 49
    label "50"
    colour "lfdred"
  ]
  node [
    id 50
    label "51"
    colour "lfdred"
  ]
  node [
    id 51
    label "52"
    colour "lfdred"
  ]
  node [
    id 52
    label "53"
    colour "lfdred"
  ]
  node [
    id 53
    label "54"
    colour "lfdred"
  ]
  node [
    id 54
    label "55"
    colour "lfdred"
  ]
  node [
    id 55
    label "56"
    colour "lfdred"
  ]
  node [
    id 56
    label "57"
    colour "lfdred"
  ]
  node [
    id 57
    label "58"
    colour "lfdred"
  ]
  node [
    id 58
    label "59"
    colour "lfdred"
  ]
  node [
    id 59
    label "60"
    colour "lfdred"
  ]
  node [
    id 60
    label "61"
    colour "lfdred"
  ]
  node [
    id 61
    label "62"
    colour "lfdred"
  ]
  node [
    id 62
    label "63"
    colour "lfdred"
  ]
  node [
    id 63
    label "64"
    colour "lfdred"
  ]
  node [
    id 64
    label "65"
    colour "lfdred"
  ]
  node [
    id 65
    label "66"
    colour "lfdred"
  ]
  node [
    id 66
    label "67"
    colour "lfdred"
  ]
  node [
    id 67
    label "68"
    colour "lfdred"
  ]
  node [
    id 68
    label "69"
    colour "lfdred"
  ]
  node [
    id 69
    label "70"
    colour "lfdred"
  ]
  node [
    id 70
    label "71"
    colour "lfdred"
  ]
  node [
    id 71
    label "72"
    colour "lfdred"
  ]
  node [
    id 72
    label "73"
    colour "lfdred"
  ]
  node [
    id 73
    label "74"
    colour "lfdred"
  ]
  node [
    id 74
    label "75"
    colour "lfdred"
  ]
  node [
    id 75
    label "76"
    colour "lfdred"
  ]
  edge [
    source 0
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 37
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 42
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 64
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 66
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 70
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 47
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 52
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 65
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 36
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 44
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 48
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 54
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 57
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 63
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 43
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 60
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 75
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 41
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 53
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 71
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 4
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 38
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 49
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 3
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 50
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 37
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 64
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 39
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 67
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 72
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 73
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 42
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 50
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 38
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 42
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 6
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 37
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 43
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 38
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 66
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 45
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 56
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 58
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 60
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 40
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 51
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 63
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 68
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 49
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 55
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 65
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 61
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 45
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 74
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 61
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 48
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 51
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 71
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 74
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 75
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 52
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 62
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 36
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 39
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 46
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 61
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 36
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 39
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 44
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 47
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 67
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 69
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 59
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 68
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 41
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 46
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 62
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 70
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 40
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 69
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 72
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 59
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 56
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 72
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 59
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 36
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 40
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 53
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 41
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 44
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 46
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 41
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 42
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 45
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 57
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 58
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 70
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 71
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 38
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 54
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 44
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 47
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 48
    weight 1
    colour "lfdred"
  ]
  edge [
    source 20
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 20
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 20
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 20
    target 49
    weight 1
    colour "lfdred"
  ]
  edge [
    source 21
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 21
    target 42
    weight 1
    colour "lfdred"
  ]
  edge [
    source 21
    target 37
    weight 1
    colour "lfdred"
  ]
  edge [
    source 21
    target 65
    weight 1
    colour "lfdred"
  ]
  edge [
    source 21
    target 73
    weight 1
    colour "lfdred"
  ]
  edge [
    source 22
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 22
    target 39
    weight 1
    colour "lfdred"
  ]
  edge [
    source 23
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 23
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 23
    target 46
    weight 1
    colour "lfdred"
  ]
  edge [
    source 23
    target 52
    weight 1
    colour "lfdred"
  ]
  edge [
    source 23
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 23
    target 55
    weight 1
    colour "lfdred"
  ]
  edge [
    source 24
    target 43
    weight 1
    colour "lfdred"
  ]
  edge [
    source 24
    target 53
    weight 1
    colour "lfdred"
  ]
  edge [
    source 24
    target 54
    weight 1
    colour "lfdred"
  ]
  edge [
    source 25
    target 51
    weight 1
    colour "lfdred"
  ]
  edge [
    source 25
    target 55
    weight 1
    colour "lfdred"
  ]
  edge [
    source 26
    target 40
    weight 1
    colour "lfdred"
  ]
  edge [
    source 26
    target 65
    weight 1
    colour "lfdred"
  ]
  edge [
    source 26
    target 56
    weight 1
    colour "lfdred"
  ]
  edge [
    source 27
    target 43
    weight 1
    colour "lfdred"
  ]
  edge [
    source 27
    target 50
    weight 1
    colour "lfdred"
  ]
  edge [
    source 27
    target 68
    weight 1
    colour "lfdred"
  ]
  edge [
    source 27
    target 57
    weight 1
    colour "lfdred"
  ]
  edge [
    source 28
    target 58
    weight 1
    colour "lfdred"
  ]
  edge [
    source 28
    target 59
    weight 1
    colour "lfdred"
  ]
  edge [
    source 29
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 29
    target 38
    weight 1
    colour "lfdred"
  ]
  edge [
    source 30
    target 60
    weight 1
    colour "lfdred"
  ]
  edge [
    source 30
    target 62
    weight 1
    colour "lfdred"
  ]
  edge [
    source 31
    target 51
    weight 1
    colour "lfdred"
  ]
  edge [
    source 32
    target 73
    weight 1
    colour "lfdred"
  ]
  edge [
    source 32
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 32
    target 63
    weight 1
    colour "lfdred"
  ]
  edge [
    source 33
    target 36
    weight 1
    colour "lfdred"
  ]
  edge [
    source 33
    target 63
    weight 1
    colour "lfdred"
  ]
  edge [
    source 34
    target 50
    weight 1
    colour "lfdred"
  ]
  edge [
    source 34
    target 68
    weight 1
    colour "lfdred"
  ]
  edge [
    source 35
    target 61
    weight 1
    colour "lfdred"
  ]
  edge [
    source 37
    target 64
    weight 1
    colour "lfdred"
  ]
  edge [
    source 38
    target 66
    weight 1
    colour "lfdred"
  ]
  edge [
    source 39
    target 67
    weight 1
    colour "lfdred"
  ]
  edge [
    source 40
    target 69
    weight 1
    colour "lfdred"
  ]
  edge [
    source 43
    target 74
    weight 1
    colour "lfdred"
  ]
  edge [
    source 45
    target 75
    weight 1
    colour "lfdred"
  ]
]
