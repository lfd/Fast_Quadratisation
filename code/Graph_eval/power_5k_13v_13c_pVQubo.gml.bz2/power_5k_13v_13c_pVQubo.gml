graph [
  node [
    id 0
    label "1"
    colour "lfdblack"
  ]
  node [
    id 1
    label "2"
    colour "lfdblack"
  ]
  node [
    id 2
    label "3"
    colour "lfdblack"
  ]
  node [
    id 3
    label "4"
    colour "lfdblack"
  ]
  node [
    id 4
    label "5"
    colour "lfdblack"
  ]
  node [
    id 5
    label "6"
    colour "lfdblack"
  ]
  node [
    id 6
    label "7"
    colour "lfdblack"
  ]
  node [
    id 7
    label "8"
    colour "lfdblack"
  ]
  node [
    id 8
    label "9"
    colour "lfdblack"
  ]
  node [
    id 9
    label "10"
    colour "lfdblack"
  ]
  node [
    id 10
    label "11"
    colour "lfdblack"
  ]
  node [
    id 11
    label "12"
    colour "lfdblack"
  ]
  node [
    id 12
    label "13"
    colour "lfdblack"
  ]
  node [
    id 13
    label "14"
    colour "lfdred"
  ]
  node [
    id 14
    label "15"
    colour "lfdred"
  ]
  node [
    id 15
    label "16"
    colour "lfdred"
  ]
  node [
    id 16
    label "17"
    colour "lfdred"
  ]
  node [
    id 17
    label "18"
    colour "lfdred"
  ]
  node [
    id 18
    label "19"
    colour "lfdred"
  ]
  node [
    id 19
    label "20"
    colour "lfdred"
  ]
  node [
    id 20
    label "21"
    colour "lfdred"
  ]
  node [
    id 21
    label "22"
    colour "lfdred"
  ]
  node [
    id 22
    label "23"
    colour "lfdred"
  ]
  node [
    id 23
    label "24"
    colour "lfdred"
  ]
  node [
    id 24
    label "25"
    colour "lfdred"
  ]
  node [
    id 25
    label "26"
    colour "lfdred"
  ]
  node [
    id 26
    label "27"
    colour "lfdred"
  ]
  node [
    id 27
    label "28"
    colour "lfdred"
  ]
  node [
    id 28
    label "29"
    colour "lfdred"
  ]
  node [
    id 29
    label "30"
    colour "lfdred"
  ]
  node [
    id 30
    label "31"
    colour "lfdred"
  ]
  node [
    id 31
    label "32"
    colour "lfdred"
  ]
  node [
    id 32
    label "33"
    colour "lfdred"
  ]
  node [
    id 33
    label "34"
    colour "lfdred"
  ]
  node [
    id 34
    label "35"
    colour "lfdred"
  ]
  node [
    id 35
    label "36"
    colour "lfdred"
  ]
  node [
    id 36
    label "37"
    colour "lfdred"
  ]
  edge [
    source 0
    target 2
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 4
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 36
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 0
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 1
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 3
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 2
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 3
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 4
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 5
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 6
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 7
    target 36
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 8
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 9
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 10
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 11
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 15
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 13
    weight 1
    colour "lfdred"
  ]
  edge [
    source 12
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 14
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 16
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 22
    weight 1
    colour "lfdred"
  ]
  edge [
    source 13
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 17
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 24
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 25
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 20
    weight 1
    colour "lfdred"
  ]
  edge [
    source 14
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 18
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 19
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 26
    weight 1
    colour "lfdred"
  ]
  edge [
    source 15
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 27
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 31
    weight 1
    colour "lfdred"
  ]
  edge [
    source 16
    target 32
    weight 1
    colour "lfdred"
  ]
  edge [
    source 17
    target 30
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 21
    weight 1
    colour "lfdred"
  ]
  edge [
    source 18
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 23
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 28
    weight 1
    colour "lfdred"
  ]
  edge [
    source 19
    target 29
    weight 1
    colour "lfdred"
  ]
  edge [
    source 20
    target 33
    weight 1
    colour "lfdred"
  ]
  edge [
    source 20
    target 34
    weight 1
    colour "lfdred"
  ]
  edge [
    source 22
    target 35
    weight 1
    colour "lfdred"
  ]
  edge [
    source 22
    target 36
    weight 1
    colour "lfdred"
  ]
]
