graph [
  node [
    id 0
    label "1"
    colour "lfdblack"
  ]
  node [
    id 1
    label "2"
    colour "lfdblack"
  ]
  node [
    id 2
    label "3"
    colour "lfdblack"
  ]
  node [
    id 3
    label "4"
    colour "lfdblack"
  ]
  node [
    id 4
    label "5"
    colour "lfdblack"
  ]
  node [
    id 5
    label "6"
    colour "lfdblack"
  ]
  node [
    id 6
    label "7"
    colour "lfdblack"
  ]
  node [
    id 7
    label "8"
    colour "lfdblack"
  ]
  node [
    id 8
    label "9"
    colour "lfdblack"
  ]
  node [
    id 9
    label "10"
    colour "lfdblack"
  ]
  node [
    id 10
    label "11"
    colour "lfdblack"
  ]
  node [
    id 11
    label "12"
    colour "lfdblack"
  ]
  node [
    id 12
    label "13"
    colour "lfdblack"
  ]
  node [
    id 13
    label "14"
    colour "lfdblack"
  ]
  node [
    id 14
    label "15"
    colour "lfdblack"
  ]
  node [
    id 15
    label "16"
    colour "lfdblack"
  ]
  node [
    id 16
    label "17"
    colour "lfdblack"
  ]
  node [
    id 17
    label "18"
    colour "lfdblack"
  ]
  node [
    id 18
    label "19"
    colour "lfdblack"
  ]
  node [
    id 19
    label "20"
    colour "lfdblack"
  ]
  node [
    id 20
    label "21"
    colour "lfdblack"
  ]
  node [
    id 21
    label "22"
    colour "lfdblack"
  ]
  node [
    id 22
    label "23"
    colour "lfdblack"
  ]
  node [
    id 23
    label "24"
    colour "lfdblack"
  ]
  node [
    id 24
    label "25"
    colour "lfdblack"
  ]
  node [
    id 25
    label "26"
    colour "lfdblack"
  ]
  node [
    id 26
    label "27"
    colour "lfdblack"
  ]
  node [
    id 27
    label "28"
    colour "lfdblack"
  ]
  node [
    id 28
    label "29"
    colour "lfdblack"
  ]
  node [
    id 29
    label "30"
    colour "lfdblack"
  ]
  node [
    id 30
    label "31"
    colour "lfdblack"
  ]
  node [
    id 31
    label "32"
    colour "lfdblack"
  ]
  node [
    id 32
    label "33"
    colour "lfdblack"
  ]
  node [
    id 33
    label "34"
    colour "lfdblack"
  ]
  node [
    id 34
    label "35"
    colour "lfdblack"
  ]
  node [
    id 35
    label "36"
    colour "lfdblack"
  ]
  node [
    id 36
    label "37"
    colour "lfdblack"
  ]
  node [
    id 37
    label "38"
    colour "lfdblack"
  ]
  node [
    id 38
    label "39"
    colour "lfdblack"
  ]
  node [
    id 39
    label "40"
    colour "lfdblack"
  ]
  node [
    id 40
    label "41"
    colour "lfdblack"
  ]
  node [
    id 41
    label "42"
    colour "lfdblack"
  ]
  node [
    id 42
    label "43"
    colour "lfdblack"
  ]
  node [
    id 43
    label "44"
    colour "lfdblack"
  ]
  node [
    id 44
    label "45"
    colour "lfdblack"
  ]
  node [
    id 45
    label "46"
    colour "lfdblack"
  ]
  node [
    id 46
    label "47"
    colour "lfdblack"
  ]
  node [
    id 47
    label "48"
    colour "lfdblack"
  ]
  node [
    id 48
    label "49"
    colour "lfdblack"
  ]
  node [
    id 49
    label "50"
    colour "lfdblack"
  ]
  node [
    id 50
    label "51"
    colour "lfdblack"
  ]
  node [
    id 51
    label "52"
    colour "lfdblack"
  ]
  node [
    id 52
    label "53"
    colour "lfdblack"
  ]
  node [
    id 53
    label "54"
    colour "lfdblack"
  ]
  node [
    id 54
    label "55"
    colour "lfdblack"
  ]
  node [
    id 55
    label "56"
    colour "lfdblack"
  ]
  node [
    id 56
    label "57"
    colour "lfdblack"
  ]
  node [
    id 57
    label "58"
    colour "lfdblack"
  ]
  node [
    id 58
    label "59"
    colour "lfdblack"
  ]
  node [
    id 59
    label "60"
    colour "lfdblack"
  ]
  node [
    id 60
    label "61"
    colour "lfdblack"
  ]
  node [
    id 61
    label "62"
    colour "lfdblack"
  ]
  node [
    id 62
    label "63"
    colour "lfdblack"
  ]
  node [
    id 63
    label "64"
    colour "lfdblack"
  ]
  node [
    id 64
    label "65"
    colour "lfdblack"
  ]
  node [
    id 65
    label "66"
    colour "lfdblack"
  ]
  edge [
    source 0
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 28
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 29
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 31
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 38
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 45
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 22
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 6
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 33
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 2
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 36
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 41
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 17
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 0
    target 44
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 6
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 22
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 30
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 35
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 49
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 55
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 23
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 28
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 46
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 50
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 1
    target 54
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 30
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 40
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 43
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 48
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 52
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 56
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 61
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 27
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 17
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 34
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 36
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 42
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 58
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 2
    target 59
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 6
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 32
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 33
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 36
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 51
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 59
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 62
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 17
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 31
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 20
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 3
    target 38
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 17
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 22
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 35
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 36
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 41
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 44
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 64
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 65
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 5
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 26
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 43
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 45
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 48
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 33
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 4
    target 63
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 17
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 20
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 23
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 29
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 31
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 34
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 38
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 6
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 32
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 46
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 7
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 47
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 5
    target 61
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 23
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 20
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 30
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 32
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 33
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 51
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 53
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 55
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 6
    target 56
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 8
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 30
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 44
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 54
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 57
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 9
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 11
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 26
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 47
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 49
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 7
    target 58
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 23
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 26
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 27
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 28
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 34
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 37
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 39
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 8
    target 55
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 10
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 15
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 22
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 42
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 46
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 50
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 20
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 31
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 12
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 39
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 9
    target 52
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 29
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 39
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 17
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 22
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 35
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 40
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 10
    target 43
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 22
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 32
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 35
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 40
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 43
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 53
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 23
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 27
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 41
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 60
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 13
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 11
    target 65
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 47
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 48
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 49
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 63
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 29
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 20
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 37
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 39
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 51
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 32
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 12
    target 62
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 14
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 26
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 29
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 31
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 34
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 38
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 45
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 18
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 35
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 42
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 49
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 17
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 64
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 13
    target 65
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 16
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 22
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 41
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 42
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 60
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 28
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 29
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 14
    target 61
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 20
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 23
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 26
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 27
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 28
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 34
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 58
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 30
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 15
    target 50
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 19
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 26
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 27
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 28
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 37
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 39
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 59
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 16
    target 60
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 17
    target 47
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 17
    target 34
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 17
    target 44
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 17
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 17
    target 57
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 17
    target 64
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 18
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 18
    target 26
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 18
    target 27
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 18
    target 52
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 18
    target 53
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 18
    target 54
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 19
    target 21
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 19
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 19
    target 32
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 19
    target 33
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 19
    target 44
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 19
    target 45
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 20
    target 41
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 20
    target 46
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 20
    target 50
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 20
    target 60
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 20
    target 37
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 20
    target 38
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 21
    target 24
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 21
    target 40
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 21
    target 56
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 21
    target 57
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 22
    target 23
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 22
    target 29
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 22
    target 37
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 22
    target 39
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 22
    target 51
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 23
    target 25
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 23
    target 30
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 23
    target 35
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 23
    target 55
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 24
    target 51
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 24
    target 62
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 25
    target 48
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 26
    target 36
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 26
    target 42
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 27
    target 40
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 27
    target 43
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 28
    target 33
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 30
    target 58
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 31
    target 36
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 31
    target 59
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 32
    target 62
    weight 1
    colour "lfdblack"
  ]
  edge [
    source 33
    target 63
    weight 1
    colour "lfdblack"
  ]
]
